#include <iostream>
#include <GL/glut.h> 
#include <random>
#include <time.h>
#include <math.h>
using namespace std;
#define WINWIDTH 520
#define WINHEIGHT 720

GLvoid drawScene(GLvoid);
GLvoid Reshape(int w, int h);

class Figure {
public:
	int x = 60, y = WINHEIGHT - 60;
	int type = 5; //3,4,5,6
	int side = 90;
	int line = 1; //1,2,3,4,5
	double r = 0;
	GLvoid Draw(GLvoid) {
		glColor3f(0, 0, 1);
		x += 100*(line - 1);
		switch (type) {
		case 3:
			glBegin(GL_POLYGON);
			glVertex2i(x, y + (sqrt(3) / 3)*side);
			glVertex2i(x - side / 2, y - (sqrt(3) / 6)*side);
			glVertex2i(x + side / 2, y - (sqrt(3) / 6)*side);
			glEnd();
			break;
		case 4:
			glBegin(GL_POLYGON);
			glVertex2i(x - side / 2, y + side / 2);
			glVertex2i(x + side / 2, y + side / 2);
			glVertex2i(x + side / 2, y - side / 2);
			glVertex2i(x - side / 2, y - side / 2);
			glEnd();
			break;
		case 5:
			r = 1.168*(side/2)*sin((72.0 / 180.0)*3.141592);
			glBegin(GL_POLYGON);
			glVertex2f(x + r*cos(0), y + r*sin(0));
			glVertex2f(x + r*cos((72.0 / 180.0)*3.141592), y + r*sin((72.0 / 180.0)*3.141592));
			glVertex2f(x + r*cos((144.0 / 180.0)*3.141592), y + r*sin((144.0/ 180.0)*3.141592));
			glVertex2f(x + r*cos((216.0 / 180.0)*3.141592), y + r*sin((216.0/ 180.0)*3.141592));
			glVertex2f(x + r*cos((288.0 / 180.0)*3.141592), y + r*sin((288.0/ 180.0)*3.141592));
			glEnd();
			break;
		}
	}

	void Move() {
		y -= 10;
	}
};

void main(int argc, char *argv[])
{
	//�ʱ�ȭ �Լ���
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA); // ���÷��� ��� ����
	glutInitWindowPosition(500, 0); // �������� ��ġ����
	glutInitWindowSize(WINWIDTH,WINHEIGHT); // �������� ũ�� ����
	glutCreateWindow("������ �����!"); // ������ ���� (������ �̸�)
	glutDisplayFunc(drawScene); // ��� �Լ��� ����
	glutReshapeFunc(Reshape);
	glutMainLoop();
}
// ������ ��� �Լ�
GLvoid drawScene(GLvoid)
{
	Figure triangle;

	//����
	glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT); 

	//�׵θ�
	glColor3f(1, 1, 1);
	glBegin(GL_LINES);
	glVertex2i(10, 10);
	glVertex2i(510, 10);
	glVertex2i(10, 10);
	glVertex2i(10, WINHEIGHT-10);
	glVertex2i(510, 10);
	glVertex2i(510, WINHEIGHT - 10);
	glVertex2i(10, WINHEIGHT - 10);
	glVertex2i(510, WINHEIGHT - 10);
	//���м�
	glVertex2i(110, 10);
	glVertex2i(110, WINHEIGHT - 10);
	glVertex2i(210, 10);
	glVertex2i(210, WINHEIGHT - 10);
	glVertex2i(310, 10);
	glVertex2i(310, WINHEIGHT - 10);
	glVertex2i(410, 10);
	glVertex2i(410, WINHEIGHT - 10);
	//���̽�
	glVertex2i(10, 110);
	glVertex2i(510, 110);
	glEnd();

	triangle.Draw();

	glFlush(); // ȭ�鿡 ����ϱ�
}

GLvoid Reshape(int w, int h)
{
	glViewport(0, 0, w, h);
	glOrtho(0, WINWIDTH, 0, WINHEIGHT, -1.0, 1.0);
}
